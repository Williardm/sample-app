/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testrun;
import java.util.Scanner;

public class Testrun {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner blimp = new Scanner(System.in);
        System.out.println("What is your name?");
        String name = blimp.next();
        
        Scanner beats = new Scanner(System.in);
        System.out.println("What year were you born in?");
        int age = beats.nextInt();
        int dob = 2020-age;
        
      System.out.println("Your name is: " + name);
      System.out.println("Your age is: " + dob);
    }
    
    
}
